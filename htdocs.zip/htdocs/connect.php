<?php

/* ==========================================
   NovaReads Database Connection
   InfinityFree Hosting
========================================== */

$host = "sql306.infinityfree.com";
$username = "if0_42984516";
$password = "FVWoGalnTe";
$database = "if0_42984516_novelsubsystem";

/* ==========================================
   Connect to MySQL
========================================== */

$conn = @mysqli_connect(
    $host,
    $username,
    $password,
    $database
);

$dbError = null;

/* ==========================================
   Check Connection
========================================== */

if (!$conn) {

    $dbError = mysqli_connect_error();

} else {

    /* ==========================================
       Set Character Encoding
    ========================================== */

    mysqli_set_charset($conn, "utf8mb4");

}

?>