<?php

/* =====================================
   FLUTTERWAVE CONFIGURATION
===================================== */

// Test Public Key
define(
    "FLW_PUBLIC_KEY",
    "FLWPUBK_TEST-62faa72f2b276f6fada10f064b0c49d5-X"
);

// Test Secret Key
define(
    "FLW_SECRET_KEY",
    "FLWSECK_TEST-9ce3874a5752f42a06c333239318dbc3-X"
);

// Currency
define(
    "FLW_CURRENCY",
    "NGN"
);

// Website URL
define(
    "SITE_URL",
    "http://localhost/NovaReads"
);

?>